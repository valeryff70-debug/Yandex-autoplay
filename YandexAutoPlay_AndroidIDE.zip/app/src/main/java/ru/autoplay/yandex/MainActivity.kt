package ru.autoplay.yandex
import android.app.Activity
import android.os.Bundle
import android.widget.TextView
class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(TextView(this).apply {
            text = "Yandex AutoPlay\n\nru.yandex.music\nАвтозапуск через 8 секунд"
            textSize = 18f
            setPadding(32, 48, 32, 32)
        })
    }
}
