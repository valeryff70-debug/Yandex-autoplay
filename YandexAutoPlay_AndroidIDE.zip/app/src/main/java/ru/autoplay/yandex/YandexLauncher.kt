package ru.autoplay.yandex
import android.content.Context
import android.media.AudioManager
import android.os.Handler
import android.os.Looper
import android.content.Intent
import android.view.KeyEvent

object YandexLauncher {
    private const val PACKAGE = "ru.yandex.music"
    fun launch(context: Context) {
        val intent = context.packageManager.getLaunchIntentForPackage(PACKAGE) ?: return
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        try { context.startActivity(intent) } catch (_: Throwable) { return }
        Handler(Looper.getMainLooper()).postDelayed({ sendPlay(context) }, 2500L)
    }
    private fun sendPlay(context: Context) {
        try {
            val audio = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            audio.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_MEDIA_PLAY))
            audio.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_MEDIA_PLAY))
        } catch (_: Throwable) {}
    }
}
