package ru.autoplay.yandex
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action != Intent.ACTION_BOOT_COMPLETED &&
            intent?.action != Intent.ACTION_LOCKED_BOOT_COMPLETED) return
        val pending = goAsync()
        Handler(Looper.getMainLooper()).postDelayed({
            try { YandexLauncher.launch(context) } finally { pending.finish() }
        }, 8000L)
    }
}
